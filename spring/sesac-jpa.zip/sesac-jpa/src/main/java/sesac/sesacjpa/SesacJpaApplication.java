package sesac.sesacjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SesacJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SesacJpaApplication.class, args);
	}

}
