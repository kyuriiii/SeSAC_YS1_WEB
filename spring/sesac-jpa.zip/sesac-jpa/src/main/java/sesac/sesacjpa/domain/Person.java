package sesac.sesacjpa.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Person {
	private String id;
	private String pw;
	private String name;
}
