package sesac.sesacmybatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SesacMybatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
