package sesac.sesacmybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SesacMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SesacMybatisApplication.class, args);
	}

}
