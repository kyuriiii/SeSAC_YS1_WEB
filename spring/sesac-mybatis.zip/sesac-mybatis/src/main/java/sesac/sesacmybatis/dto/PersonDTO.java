package sesac.sesacmybatis.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersonDTO {
	private String id;
	private String pw;
	private String name;
	private String nickname;
}
