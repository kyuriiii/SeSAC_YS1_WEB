const a = 1;
const b = 3;

const array = {
    a : a,
    b : b
};
module.exports = array;